<?php
$target = array (  
   'battle_id'=> 257  
   ,'user_id'=> 41248  
   ,'user_id2'=> 23989  
   ,'player'=> 41248  
   ,'formation'=> Array ('41248'=> 1  ,'23989'=> 2,'ssss'=>3)  
   ,'result'=> 1  
   ,'battle_type'=> 1  
   ,'speed'=> Array( '41248'=> 0,'23989'=> 0  )  
   ,'attacker'=> Array(  
    '1'=> Array (  
                   'user_id'=> 41248  
                   ,'soldier_id'=> 28  
                   ,'prototype_id'=> 4  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3997  
                   ,'hp'=> 3997  
                   ,'attack_general'=> 346  
                   ,'attack_skill'=> 596  
                   ,'attack_explode'=> 458  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 2  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0)  
           ,'4'=> Array (  
                   'user_id'=> 41248  
                   ,'soldier_id'=> 29  
                   ,'prototype_id'=> 2  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3555  
                   ,'hp'=> 3555  
                   ,'attack_general'=> 396  
                   ,'attack_skill'=> 581  
                   ,'attack_explode'=> 418  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0  
                )  
           ,'5'=> Array                (  
                   'user_id'=> 41248  
                   ,'soldier_id'=> 30  
                   ,'prototype_id'=> 6  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3043  
                   ,'hp'=> 3043  
                   ,'attack_general'=> 351  
                   ,'attack_skill'=> 540  
                   ,'attack_explode'=> 474  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0)  
           ,'7'=> Array (  
                   'user_id'=> 41248  
                   ,'soldier_id'=> 37  
                   ,'prototype_id'=> 2  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3491  
                   ,'hp'=> 3491  
                   ,'attack_general'=> 393  
                   ,'attack_skill'=> 532  
                   ,'attack_explode'=> 456  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0   ))  
   ,'defender'=> Array(  
           '2'=> Array(  
                   'user_id'=> 23989  
                   ,'soldier_id'=> 24  
                   ,'prototype_id'=> 1  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3230  
                   ,'hp'=> 3230  
                   ,'attack_general'=> 390  
                   ,'attack_skill'=> 567  
                   ,'attack_explode'=> 442  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0)  
           ,'5'=> Array(  
                   'user_id'=> 23989  
                   ,'soldier_id'=> 25  
                   ,'prototype_id'=> 2  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3400  
                   ,'hp'=> 3400  
                   ,'attack_general'=> 379  
                   ,'attack_skill'=> 536  
                   ,'attack_explode'=> 405  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0 )  
           ,'7'=> Array(  
                   'user_id'=> 23989  
                   ,'soldier_id'=> 26  
                   ,'prototype_id'=> 6  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3669  
                   ,'hp'=> 3669  
                   ,'attack_general'=> 362  
                   ,'attack_skill'=> 549  
                   ,'attack_explode'=> 426  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0 )  
           ,'9'=> Array(  
                   'user_id'=> 23989  
                   ,'soldier_id'=> 27  
                   ,'prototype_id'=> 1  
                   ,'bid'=> 1  
                   ,'level'=> 1  
                   ,'rare'=> 1  
                   ,'skill_id'=> 1  
                   ,'totalhp'=> 3618  
                   ,'hp'=> 3618  
                   ,'attack_general'=> 326  
                   ,'attack_skill'=> 510  
                   ,'attack_explode'=> 419  
                   ,'attack_type'=> 1  
                   ,'defense'=> 0  
                   ,'anger'=> 50  
                   ,'dodge'=> 2  
                   ,'crit'=> 2  
                   ,'block'=> 0  
                   ,'block_effect'=> 0.5  
                   ,'crit_effect'=> 2  
                   ,'foramtion_effect'=> 0) )  
   ,'battle_process'=> Array(  
           '0'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'1'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'2'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'3'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'4'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'5'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'6'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'7'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'8'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'9'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'10'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'11'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'12'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'13'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'14'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'15'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'16'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'17'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'18'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
           ,'19'=> Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
  
           ,'20'=>Array(  
                   'user_id'=> 41248  
                   ,'asid'=> 28  
                   ,'bsid'=> 'danger'  
                   ,'harm'=> 'danger2'  
                   ,'dhp'=> Array('0'=> 2019  )  
                   ,'attacker_anger'=> 66  
                   ,'defender_anger'=> Array('0'=> 94 )  
                   ,'skill'=> 0  
                   ,'state'=> 0  
                )  
        )  
  
); 
$json = json_encode($target);
$seri = serialize($target);
$sw = swoole_serialize::pack($target);
var_dump("json :". strlen($json));
var_dump("serialize :". strlen($seri));
var_dump("swoole :". strlen($sw));
$stime = microtime(true);
for ($i = 0; $i < 50000; $i ++) {
    json_encode($target);
}
$etime = microtime(true);
var_dump("json_encode :". ($etime - $stime));
//----------------------------------    
$stime = microtime(true);
for ($i = 0; $i < 50000; $i ++) {
    json_decode($json. true);
}
$etime = microtime(true);
var_dump("json_decode :". ($etime - $stime));
//----------------------------------    
$stime = microtime(true);
for ($i = 0; $i < 50000; $i ++) {
    serialize($target);
}
$etime = microtime(true);
var_dump("serialize :". ($etime - $stime));
//----------------------------------    
$stime = microtime(true);
for ($i = 0; $i < 50000; $i ++) {
    unserialize($seri);
}
$etime = microtime(true);
var_dump("unserialize :". ($etime - $stime));
//----------------------------------    
//----------------------------------    
//----------------------------------    
$stime = microtime(true);
for ($i = 0; $i < 50000; $i ++) {
    swoole_serialize::pack($target);
}
$etime = microtime(true);
var_dump("swoole_serialize :". ($etime - $stime));
$stime = microtime(true);
for ($i = 0; $i < 50000; $i ++) {
 swoole_serialize::unpack($sw);
}
$etime = microtime(true);
var_dump("swoole_unserialize :". ($etime - $stime));
?> 